import React from 'react';
import '../style/header.css';

function Header() {
  return (
    <div className="Header">
      <h1> My list of Todo</h1>
    </div>
  );
}

export default Header;
